import * as vscode from 'vscode';
import { randomUUID } from 'node:crypto';
import { mkdir, open, readFile, rename, unlink, writeFile } from 'node:fs/promises';
import { isAbsolute, join } from 'node:path';
import { claimSchedule, fresh, nextCron, parseQuota, validateProfiles } from './domain';
import type { Job, Profile, Quota, Role, Schedule } from './domain';
import { Engine, newJob, stepPrompt } from './engine';
import { execute } from './runner';

interface State { version: 1; roles: Record<Role, string>; jobs: Job[]; schedules: Schedule[]; quotas: Record<string, Quota> }
const roles: Role[] = ['builder', 'auditor', 'worker', 'lead'];
let shutdown: (() => Promise<void>) | undefined;
const initial = (): State => ({ version: 1, roles: { builder: 'codex-main', auditor: 'claude-main', worker: 'gemini-main', lead: 'codex-main' }, jobs: [], schedules: [], quotas: {} });
type Node = vscode.TreeItem & { children?: Node[] };
function node(label: string, description?: string, command?: string, arg?: unknown, children?: Node[]): Node {
  const item: Node = new vscode.TreeItem(label, children ? vscode.TreeItemCollapsibleState.Expanded : vscode.TreeItemCollapsibleState.None);
  item.description = description;
  item.children = children;
  if (command) item.command = { command, title: label, arguments: arg === undefined ? [] : [arg] };
  return item;
}

export async function activate(context: vscode.ExtensionContext): Promise<void> {
  if (!vscode.workspace.isTrusted || !context.storageUri) return;
  const roots = vscode.workspace.workspaceFolders;
  if (!roots?.length) return;
  const storage = context.storageUri.fsPath;
  await mkdir(storage, { recursive: true });
  const lockPath = join(storage, 'runner.lock');
  const lock = async () => {
    try { const f = await open(lockPath, 'wx'); await f.writeFile(String(process.pid)); await f.close(); return true; }
    catch (e: any) {
      if (e.code !== 'EEXIST') throw e;
      const pid = Number(await readFile(lockPath, 'utf8'));
      if (!Number.isInteger(pid) || pid <= 0) return false;
      try { process.kill(pid, 0); return false; }
      catch (probe: any) { if (probe.code !== 'ESRCH') return false; }
      await unlink(lockPath);
      try { const f = await open(lockPath, 'wx'); await f.writeFile(String(process.pid)); await f.close(); return true; }
      catch { return false; }
    }
  };
  if (!await lock()) {
    void vscode.window.showWarningMessage('AI Team: this workspace already has a runner in another window.');
    return;
  }
  let released = false;
  const release = async () => {
    if (released) return;
    released = true;
    try { if (await readFile(lockPath, 'utf8') === String(process.pid)) await unlink(lockPath); } catch { /* closed */ }
  };
  // Keep the lock until process exit on deactivation if a child is still stopping.
  // A subsequent host can recover the stale PID lock.
  let state = initial();
  const statePath = join(storage, 'state.json');
  try {
    const parsed = JSON.parse(await readFile(statePath, 'utf8'));
    if (parsed.version !== 1 || !Array.isArray(parsed.jobs) || !Array.isArray(parsed.schedules) || !parsed.roles || !parsed.quotas) {
      throw new Error('Unsupported state file. Preserve it and inspect before resetting.');
    }
    state = parsed;
  } catch (e: any) {
    if (e.code !== 'ENOENT') { await release(); throw e; }
  }
  for (const j of state.jobs) if (j.status === 'running' || j.status === 'queued') {
    j.status = 'interrupted'; j.error = 'Extension host stopped. Inspect repository changes before starting a new task.';
    for (const s of j.steps) if (s.status === 'running') s.status = 'failed';
  }
  let writeQueue = Promise.resolve();
  const save = () => {
    const snapshot = JSON.stringify(state, null, 2);
    writeQueue = writeQueue.catch(() => {}).then(async () => {
      const tmp = `${statePath}.${randomUUID()}.tmp`;
      await writeFile(tmp, snapshot, 'utf8');
      await rename(tmp, statePath);
    });
    return writeQueue;
  };
  const output = vscode.window.createOutputChannel('AI Team');
  const events = new vscode.EventEmitter<Node | undefined>();
  const status = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 90);
  status.command = 'aiTeam.switch';
  const cfg = () => vscode.workspace.getConfiguration('aiTeam');
  const profiles = () => validateProfiles(cfg().get('profiles'));
  const announced = new Set(state.jobs.filter(j => !['running', 'queued'].includes(j.status)).map(j => j.id));
  const reportText = (job: Job) => `# AI Team · ${job.id}\n\nStatus: ${job.status}\n\nWorkspace: ${job.cwd}\n\nOwner task:\n\n${job.prompt}\n\n${job.error ?? ''}\n\n`
    + job.steps.map(s => `## ${s.title} · ${s.role}\n\nProfile: ${s.profileId ?? job.roles[s.role]} · ${s.status}\n\n${s.error ?? ''}\n\n${s.response ?? '(No response yet)'}\n`).join('\n')
    + (job.audit ? '\n## Issue drafts\n\n' + job.audit.issues.map(i => `### ${i.severity}: ${i.title}\n\n${i.body}\n`).join('\n') : '');
  const persistReports = async () => {
    await mkdir(join(storage, 'reports'), { recursive: true });
    for (const job of state.jobs) await writeFile(join(storage, 'reports', `${job.id}.md`), reportText(job), 'utf8');
  };
  const quotaLabel = (id: string) => {
    const q = state.quotas[id];
    return fresh(q) ? `${q.usedPercent}% used · ${q.source}` : q ? 'stale / reset · refresh required' : 'quota unknown';
  };
  const changed = () => {
    events.fire(undefined);
    try {
      const active = state.jobs.find(j => j.status === 'running');
      status.text = `$(hubot) ${active ? active.steps.find(s => s.status === 'running')?.role ?? 'running' : 'AI Team'} · `
        + roles.filter(r => r !== 'worker').map(r => `${r[0].toUpperCase()}: ${quotaLabel(state.roles[r]).split(' · ')[0]}`).join(' | ');
      status.tooltip = profiles().map(p => `${p.label} (${p.model || 'CLI default'}): ${quotaLabel(p.id)}`).join('\n');
    } catch { status.text = '$(warning) AI Team: fix profiles'; }
    status.show();
    for (const j of state.jobs) if (!['queued', 'running'].includes(j.status) && !announced.has(j.id)) {
      announced.add(j.id);
      const message = `AI Team: ${j.status} · ${j.prompt.slice(0, 70)}`;
      const notification = ['completed', 'cancelled'].includes(j.status) ? vscode.window.showInformationMessage : vscode.window.showWarningMessage;
      void notification(message, 'Report').then(choice => { if (choice) void vscode.commands.executeCommand('aiTeam.report', j.id); });
    }
  };
  const engine = new Engine(state.jobs, {
    profiles, quotas: () => state.quotas,
    settings: () => ({ autoSwitch: cfg().get('autoSwitch', false), threshold: cfg().get('quotaThreshold', 95), maxTasks: cfg().get('maxChildTasks', 4), edits: cfg().get('allowEdits', false) }),
    changed, save: async () => { await save(); await persistReports(); },
    run: async (profile, step, job, edits, signal) => {
      const secrets: Record<string, string> = {};
      for (const key of profile.secretEnv ?? []) {
        const value = await context.secrets.get(`aiTeam:${profile.id}:${key}`);
        if (!value) throw new Error(`Missing secret ${key} for ${profile.label}. Use Store Profile Secret.`);
        secrets[key] = value;
      }
      output.appendLine(`[${job.id}] ${step.role} → ${profile.id}, model=${profile.model || 'CLI default'}, effort=${profile.effort || 'default'}, edits=${edits}`);
      const result = await execute({ profile, prompt: stepPrompt(job, step), cwd: job.cwd, edits, signal, secretValues: secrets,
        timeoutMs: cfg().get('timeoutMinutes', 30) * 60_000,
        log: text => { output.append(text); void appendRunLog(job.id, text); }
      });
      return result;
    }
  });
  let logQueue = Promise.resolve();
  const appendRunLog = (id: string, text: string) => {
    logQueue = logQueue.catch(() => {}).then(async () => {
      const file = join(storage, `${id}.log`);
      const handle = await open(file, 'a');
      try { await handle.writeFile(text, 'utf8'); } finally { await handle.close(); }
    });
    return logQueue;
  };
  const guard = async (action: () => unknown | Promise<unknown>) => {
    try { return await action(); } catch (e) { void vscode.window.showErrorMessage(`AI Team: ${e instanceof Error ? e.message : String(e)}`); }
  };
  const command = (id: string, handler: (...args: any[]) => unknown) => context.subscriptions.push(vscode.commands.registerCommand(id, (...args) => guard(() => handler(...args))));
  const provider: vscode.TreeDataProvider<Node> = {
    onDidChangeTreeData: events.event,
    getTreeItem: item => item,
    getChildren: parent => {
      if (parent) return parent.children ?? [];
      let accountNodes: Node[];
      try { accountNodes = profiles().map(p => {
        const q = state.quotas[p.id];
        const item = node(p.label, `${p.model || 'CLI default'} · ${quotaLabel(p.id)}`, 'aiTeam.quota', p.id);
        item.tooltip = `${p.id}\nExecutable: ${p.executable}\nAssigned roles: ${roles.filter(r => state.roles[r] === p.id).join(', ') || 'none'}\nObserved: ${q?.observedAt ?? 'unknown'}\nResets: ${q?.resetsAt ?? 'unknown'}`;
        return item;
      }); } catch (e) { accountNodes = [node(String(e), '', 'aiTeam.profiles')]; }
      return [
        node('New task', 'Builder → Audit → Repairs → Lead', 'aiTeam.newTask'),
        node('Roles / switch account', undefined, 'aiTeam.switch'),
        node('Schedule / remind me', undefined, 'aiTeam.schedule'),
        node('Stop queued / running task', undefined, 'aiTeam.cancel'),
        node('Configure profiles', undefined, 'aiTeam.profiles'),
        node('Accounts & quotas', undefined, undefined, undefined, accountNodes),
        node('Tasks', undefined, undefined, undefined, state.jobs.slice().reverse().map(j => node(j.prompt.slice(0, 80), j.status, 'aiTeam.report', j.id))),
        node('Schedules', undefined, undefined, undefined, state.schedules.map(s => node(s.title, `${s.enabled ? s.nextAt : 'paused'} · ${s.timezone}`, 'aiTeam.pauseSchedule', s.id)))
      ];
    }
  };
  context.subscriptions.push(output, events, status, vscode.window.registerTreeDataProvider('aiTeam.dashboard', provider));
  const pickProfile = async () => {
    const choice = await vscode.window.showQuickPick(profiles().map(p => ({ label: p.label, description: `${p.id} · ${p.model || 'CLI default'} · ${quotaLabel(p.id)}`, id: p.id })), { title: 'Select model / account profile' });
    return choice?.id;
  };
  const pickCwd = async () => roots.length === 1 ? roots[0].uri.fsPath : (await vscode.window.showWorkspaceFolderPick())?.uri.fsPath;
  const validateRoles = () => {
    const ids = new Set(profiles().map(p => p.id));
    for (const r of roles) if (!ids.has(state.roles[r])) throw new Error(`Assign a profile for ${r}.`);
  };
  let draining: Promise<unknown> | undefined;
  let closing = false;
  const start = () => {
    if (draining || closing) return;
    draining = guard(() => engine.drain()).finally(() => { draining = undefined; });
  };
  command('aiTeam.newTask', async () => {
    validateRoles();
    const prompt = await vscode.window.showInputBox({ title: 'Task for your AI team', prompt: 'Describe the result and acceptance criteria. CLI permissions and allowEdits apply.' });
    if (!prompt?.trim()) return;
    const cwd = await pickCwd(); if (!cwd) return;
    state.jobs.push(newJob(prompt.trim(), cwd, state.roles));
    await save(); changed(); start();
  });
  command('aiTeam.switch', async () => {
    const targets = [{ label: 'Future tasks', id: '' }, ...state.jobs.filter(j => j.status === 'queued').map(j => ({ label: `Queued: ${j.prompt.slice(0, 70)}`, id: j.id }))];
    const target = await vscode.window.showQuickPick(targets, { title: 'Select which task assignment to change' });
    if (!target) return;
    const assignments = target.id ? state.jobs.find(j => j.id === target.id)!.roles : state.roles;
    const role = await vscode.window.showQuickPick(roles.map(r => ({ label: r, description: assignments[r] })), { title: 'Select role to change' });
    if (!role) return;
    const id = await pickProfile(); if (!id) return;
    if (target.id && state.jobs.find(j => j.id === target.id)?.status !== 'queued') throw new Error('Task has already started. Only queued assignments can be changed.');
    assignments[role.label as Role] = id;
    await save(); changed();
    void vscode.window.showInformationMessage(`AI Team: ${role.label} → ${id} (${target.label}).`);
  });
  command('aiTeam.profiles', () => vscode.commands.executeCommand('workbench.action.openSettings', '@id:aiTeam.profiles'));
  command('aiTeam.settings', () => vscode.commands.executeCommand('workbench.action.openSettings', '@ext:local-ai-team.ai-team-workbench'));
  command('aiTeam.logs', () => output.show());
  command('aiTeam.secret', async () => {
    const id = await pickProfile(); if (!id) return;
    const p = profiles().find(x => x.id === id)!;
    const key = await vscode.window.showQuickPick(p.secretEnv ?? [], { title: 'Environment variable (configure secretEnv first)' });
    if (!key) return;
    const value = await vscode.window.showInputBox({ title: `Secret for ${id}: ${key}`, password: true, ignoreFocusOut: true });
    if (!value) return;
    await context.secrets.store(`aiTeam:${id}:${key}`, value);
    void vscode.window.showInformationMessage('AI Team: secret stored in VS Code SecretStorage.');
  });
  command('aiTeam.quota', async (selected?: string) => {
    const id = selected ?? await pickProfile(); if (!id) return;
    const value = await vscode.window.showInputBox({ title: `Quota used % · ${id} (manual snapshot)`, validateInput: s => s.trim() && Number.isFinite(Number(s)) && Number(s) >= 0 && Number(s) <= 100 ? undefined : 'Enter 0–100.' });
    if (value === undefined) return;
    state.quotas[id] = parseQuota({ usedPercent: Number(value), observedAt: new Date().toISOString(), source: 'manual' });
    await save(); changed();
  });
  command('aiTeam.report', async (id?: string) => {
    const chosen = id ?? (await vscode.window.showQuickPick(state.jobs.slice().reverse().map(j => ({ label: j.prompt.slice(0, 90), description: j.status, id: j.id }))))?.id;
    const job = state.jobs.find(j => j.id === chosen); if (!job) return;
    await persistReports();
    await vscode.window.showTextDocument(await vscode.workspace.openTextDocument(join(storage, 'reports', `${job.id}.md`)));
  });
  command('aiTeam.cancel', async () => {
    const choice = await vscode.window.showQuickPick(state.jobs.filter(j => ['queued', 'running'].includes(j.status)).map(j => ({ label: j.prompt.slice(0, 90), description: j.status, id: j.id })), { title: 'Stop task (existing edits remain for review)' });
    if (!choice) return;
    engine.cancel(choice.id); await save();
  });
  command('aiTeam.schedule', async () => {
    const kind = await vscode.window.showQuickPick(['reminder', 'task'] as const, { title: 'Reminder or automatic team run' });
    if (!kind) return;
    if (kind === 'task') validateRoles();
    const prompt = await vscode.window.showInputBox({ title: kind === 'task' ? 'Task to run automatically' : 'Reminder text' });
    if (!prompt?.trim()) return;
    const mode = await vscode.window.showQuickPick(['once', 'recurring cron'] as const, { title: 'Schedule frequency' });
    if (!mode) return;
    const timezone = cfg().get('timezone', 'Asia/Bangkok');
    let cron: string | undefined, nextAt: string;
    if (mode === 'once') {
      const input = await vscode.window.showInputBox({ title: 'Date/time with explicit UTC offset', placeHolder: '2026-10-17T09:00:00+07:00', validateInput: s => /(?:Z|[+-]\d\d:\d\d)$/.test(s) && Date.parse(s) > Date.now() ? undefined : 'Enter a future ISO date/time including Z or +07:00.' });
      if (!input) return;
      nextAt = new Date(input).toISOString();
    } else {
      cron = await vscode.window.showInputBox({ title: `Cron in ${timezone}`, placeHolder: '0 9 * * *  (daily at 09:00)', validateInput: s => { try { nextCron(s, timezone); return undefined; } catch { return 'Invalid cron expression or timezone.'; } } });
      if (!cron) return;
      nextAt = nextCron(cron, timezone);
    }
    const cwd = await pickCwd(); if (!cwd) return;
    state.schedules.push({ id: randomUUID(), title: prompt.slice(0, 80), kind: kind as 'reminder' | 'task', prompt: prompt.trim(), cwd, roles: { ...state.roles }, cron, nextAt, timezone, enabled: true });
    await save(); changed();
    void vscode.window.showInformationMessage(`AI Team: saved for ${new Date(nextAt).toLocaleString('vi-VN', { timeZone: timezone })} (${timezone}). VS Code must stay open. Missed automatic runs are skipped after 60 seconds.`);
  });
  command('aiTeam.pauseSchedule', async (id?: string) => {
    const selected = id ?? (await vscode.window.showQuickPick(state.schedules.map(s => ({ label: s.title, id: s.id }))))?.id;
    const s = state.schedules.find(x => x.id === selected); if (!s) return;
    if (!s.enabled && s.cron) s.nextAt = nextCron(s.cron, s.timezone);
    if (!s.enabled && !s.cron && Date.parse(s.nextAt) <= Date.now()) throw new Error('One-time occurrence has passed. Create a new schedule.');
    s.enabled = !s.enabled; await save(); changed();
  });
  let ticking = false;
  let tickInFlight: Promise<unknown> | undefined;
  const tick = async () => {
    if (ticking || closing) return;
    ticking = true;
    try {
      const now = new Date();
      for (const p of profiles()) if (p.quotaFile) {
        try {
          if (!isAbsolute(p.quotaFile)) throw new Error('Quota file must be absolute.');
          const raw = await readFile(p.quotaFile, 'utf8');
          if (raw.length > 32_000) throw new Error('Quota file too large.');
          state.quotas[p.id] = parseQuota(JSON.parse(raw));
        } catch { delete state.quotas[p.id]; }
      }
      const notifications: string[] = [];
      for (let i = 0; i < state.schedules.length; i++) {
        const s = state.schedules[i];
        try {
          const claim = claimSchedule(s, now); if (!claim) continue;
          state.schedules[i] = claim.next;
          if (s.kind === 'reminder') notifications.push(`Reminder: ${s.prompt}`);
          else if (now.getTime() - Date.parse(s.nextAt) > 60_000) notifications.push(`Skipped missed automatic task: ${s.title}. Start a new task to run now.`);
          else if (!state.jobs.some(j => j.scheduleOccurrence === claim.occurrence)) {
            const job = newJob(s.prompt, s.cwd, s.roles); job.scheduleOccurrence = claim.occurrence; state.jobs.push(job);
          }
        } catch (e) { s.enabled = false; notifications.push(`Schedule paused: ${s.title} (${String(e)})`); }
      }
      await save();
      for (const text of notifications) void vscode.window.showInformationMessage(`AI Team: ${text}`);
      changed(); start();
    } finally { ticking = false; }
  };
  const safeTick = () => {
    tickInFlight ??= guard(tick).finally(() => { tickInFlight = undefined; });
    return tickInFlight;
  };
  const timer = setInterval(() => void safeTick(), 15_000);
  context.subscriptions.push({ dispose: () => { clearInterval(timer); engine.stop(); } }, vscode.workspace.onDidChangeConfiguration(e => { if (e.affectsConfiguration('aiTeam')) changed(); }));
  shutdown = async () => {
    closing = true; clearInterval(timer); engine.stop();
    await tickInFlight; await draining; await writeQueue; await logQueue; await release();
    shutdown = undefined;
  };
  output.appendLine(`AI Team ready. State and reports: ${storage}`);
  await save(); changed(); await safeTick();
}

export async function deactivate(): Promise<void> { await shutdown?.(); }
