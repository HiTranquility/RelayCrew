import { CronExpressionParser } from 'cron-parser';

export type Provider = 'codex' | 'claude' | 'gemini';
export type Role = 'builder' | 'auditor' | 'worker' | 'lead';
export interface Profile {
  id: string; label: string; provider: Provider; executable: string;
  model?: string; effort?: string; env?: Record<string, string>; secretEnv?: string[]; quotaFile?: string;
}
export interface Quota {
  usedPercent: number; observedAt: string; resetsAt?: string; source: string;
}
export interface Issue { title: string; body: string; severity: 'bug' | 'improvement' }
export interface ChildTask { title: string; instructions: string }
export interface Audit { summary: string; issues: Issue[]; tasks: ChildTask[] }
export interface Step {
  role: Role; title: string; prompt: string; profileId?: string; response?: string;
  status: 'pending' | 'running' | 'done' | 'failed'; error?: string;
}
export interface Job {
  id: string; prompt: string; cwd: string; createdAt: string;
  status: 'queued' | 'running' | 'completed' | 'needs_attention' | 'failed' | 'cancelled' | 'interrupted';
  roles: Record<Role, string>; steps: Step[]; audit?: Audit; error?: string;
  scheduleOccurrence?: string;
}
export interface Schedule {
  id: string; title: string; kind: 'reminder' | 'task'; prompt: string; cwd: string;
  roles: Record<Role, string>; nextAt: string; cron?: string; timezone: string; enabled: boolean;
}

export function validateProfiles(value: unknown): Profile[] {
  if (!Array.isArray(value)) throw new Error('Profiles must be an array.');
  const ids = new Set<string>();
  for (const p of value) {
    if (!p || typeof p !== 'object' || !/^[a-zA-Z0-9_-]+$/.test(p.id) || ids.has(p.id)
      || !['codex', 'claude', 'gemini'].includes(p.provider)
      || typeof p.label !== 'string' || !p.label || typeof p.executable !== 'string' || !p.executable) {
      throw new Error('Each profile needs a unique id, label, provider and executable.');
    }
    ids.add(p.id);
    for (const key of ['model', 'effort', 'quotaFile']) {
      if (p[key] !== undefined && typeof p[key] !== 'string') throw new Error(`Invalid ${key}.`);
    }
    if (p.env !== undefined && (!p.env || Array.isArray(p.env) || typeof p.env !== 'object'
      || Object.entries(p.env).some(([k, v]) => !/^[A-Za-z_][A-Za-z0-9_]*$/.test(k) || typeof v !== 'string'))) {
      throw new Error('Profile env must map variable names to strings.');
    }
    if (p.secretEnv !== undefined && (!Array.isArray(p.secretEnv)
      || p.secretEnv.some((k: unknown) => typeof k !== 'string' || !/^[A-Za-z_][A-Za-z0-9_]*$/.test(k)))) {
      throw new Error('Invalid secretEnv.');
    }
  }
  return value as Profile[];
}

export function parseQuota(raw: unknown): Quota {
  const q = raw as Quota;
  if (!q || typeof q.usedPercent !== 'number' || !Number.isFinite(q.usedPercent)
    || q.usedPercent < 0 || q.usedPercent > 100 || typeof q.source !== 'string' || !q.source
    || !Number.isFinite(Date.parse(q.observedAt))
    || (q.resetsAt !== undefined && !Number.isFinite(Date.parse(q.resetsAt)))) throw new Error('Invalid quota data.');
  return { usedPercent: q.usedPercent, observedAt: q.observedAt, source: q.source, resetsAt: q.resetsAt };
}
export function fresh(q: Quota | undefined, now = Date.now()): q is Quota {
  return !!q && now - Date.parse(q.observedAt) >= 0 && now - Date.parse(q.observedAt) <= 300_000
    && (!q.resetsAt || Date.parse(q.resetsAt) > now);
}
export function routeProfile(id: string, profiles: Profile[], quotas: Record<string, Quota>, auto: boolean, threshold: number, now = Date.now()): Profile {
  const selected = profiles.find(p => p.id === id);
  if (!selected) throw new Error(`Missing profile ${id}. Configure role assignments.`);
  const q = quotas[id];
  if (!fresh(q, now) || q.usedPercent < threshold) return selected;
  if (auto) {
    const fallback = profiles.find(p => p.id !== id && p.provider === selected.provider
      && p.model === selected.model && p.effort === selected.effort
      && fresh(quotas[p.id], now) && quotas[p.id].usedPercent < threshold);
    if (fallback) return fallback;
  }
  throw new Error(`${selected.label}: quota at ${q.usedPercent}%. Select another account or wait for refresh.`);
}

function objectJson(raw: string): any {
  const text = raw.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
  return JSON.parse(text);
}
export function parseAudit(raw: string, max: number): Audit {
  const a = objectJson(raw);
  if (!a || typeof a.summary !== 'string' || !Array.isArray(a.issues) || !Array.isArray(a.tasks)
    || a.issues.some((i: any) => !i || typeof i.title !== 'string' || typeof i.body !== 'string' || !['bug', 'improvement'].includes(i.severity))
    || a.tasks.some((t: any) => !t || typeof t.title !== 'string' || typeof t.instructions !== 'string')) {
    throw new Error('Audit returned invalid JSON. Review the raw response; no repair tasks were dispatched.');
  }
  if (a.tasks.length > max) throw new Error(`Audit requested ${a.tasks.length} tasks; limit is ${max}. No repairs dispatched.`);
  return a;
}
export function parseDecision(raw: string): { decision: 'approved' | 'changes_requested'; summary: string } {
  const d = objectJson(raw);
  if (!d || !['approved', 'changes_requested'].includes(d.decision) || typeof d.summary !== 'string') {
    throw new Error('Lead must return a JSON decision: approved or changes_requested, with summary.');
  }
  return d;
}
export function nextCron(cron: string, timezone: string, after = new Date()): string {
  return CronExpressionParser.parse(cron, { tz: timezone, currentDate: after }).next().toISOString()!;
}
export function claimSchedule(s: Schedule, now: Date): { occurrence: string; next: Schedule } | undefined {
  if (!s.enabled || Date.parse(s.nextAt) > now.getTime()) return;
  return {
    occurrence: `${s.id}:${s.nextAt}`,
    next: { ...s, enabled: !!s.cron, nextAt: s.cron ? nextCron(s.cron, s.timezone, now) : s.nextAt }
  };
}

export const auditInstructions = `Audit the repository and the preceding implementation. Do not edit files.
Identify concrete bugs and best-practice problems with evidence, file paths, validation and acceptance criteria.
Return ONLY JSON: {"summary":"...","issues":[{"title":"...","body":"evidence, impact, reproduction","severity":"bug"}],"tasks":[{"title":"...","instructions":"bounded repair with acceptance criteria"}]}.
Use empty arrays when there are no findings. Do not invent findings.`;
export const leadInstructions = `Act as tech lead. Inspect the current code, repository guidance, implementation, audit findings and repairs.
Verify acceptance criteria and relevant tests. Do not edit files. Report unresolved risks to the product owner.
Return ONLY JSON: {"decision":"approved" or "changes_requested","summary":"evidence, tests, remaining issues"}.`;
