# AI Team Workbench · VS Code extension

Bản MVP điều phối Codex, Claude Code và Gemini CLI trong VS Code. Repo local: `VS-Extension`.

Owner giao nhiệm vụ → builder thực hiện → auditor đánh giá và tạo issue draft/việc sửa → worker xử lý từng việc → tech lead kiểm tra và báo cáo cho owner.

Mặc định: **Codex → Claude → Gemini → Codex**. Có thể gán bất kỳ profile nào vào từng vai trò, ví dụ Claude vừa audit vừa cleanup. Mỗi lượt là một phiên CLI mới, nhận nhiệm vụ gốc và báo cáo từ các bước trước. Chỉ kết luận `approved` hợp lệ của lead mới đánh dấu task `completed`; `changes_requested` cần owner xử lý tiếp.

## Dùng thử

1. Trong VS Code: **Extensions → … → Install from VSIX…**, chọn `ai-team-workbench-0.1.0.vsix`.
2. Mở folder repo cần làm việc và mở sidebar **AI Team**. Workspace cần được trust.
3. Đăng nhập từng CLI trong terminal của chính CLI; extension dùng session đó. Trên máy chuẩn bị bản này có Codex và Claude; chưa thấy Gemini trong PATH. Cài Gemini CLI hoặc đổi worker sang profile đang có trước khi chạy.
4. **AI Team: Configure Profiles** → chọn **Edit in settings.json** để đặt executable, model, effort và account profile. Nếu CLI không có trong PATH của VS Code, dùng đường dẫn tuyệt đối. Khởi động lại VS Code sau khi thay PATH.
5. **AI Team: Select Role / Switch Account** để gán builder/auditor/worker/lead. **AI Team: New Task** để chạy. Mặc định `allowEdits=false`, các CLI ở chế độ đọc/plan. Bật **AI Team › Allow Edits** để builder/worker được sửa file theo quyền CLI.
6. Click task để mở báo cáo; **AI Team: Show Logs** xem đầu ra CLI. **Cancel Task** dừng cây tiến trình, giữ các thay đổi đã thực hiện để review.

Lệnh tương đương để cài thủ công:

```powershell
code --install-extension "C:\Users\Admin\Downloads\VS-Extension\ai-team-workbench-0.1.0.vsix"
```

Extension chưa được publish Marketplace, chưa được cài vào VS Code của người dùng và không tự chạy công việc bằng account thật khi build/test.

## Model, reasoning và account

`model` để trống dùng mặc định của CLI. Nhập chính xác model ID tài khoản CLI hỗ trợ; `effort` truyền cho Codex/Claude, hiện Gemini không nhận trường này. Extension không tự đổi model khác khi model yêu cầu không được hỗ trợ.

Các tên bạn đề xuất như `gpt-6.1`/medium và `gemini-3.8-flash` là cấu hình mong muốn; bản này chưa xác minh chúng khả dụng với account của bạn. Không có bảng xếp hạng “mạnh nhất” mặc định: owner gán profile cho vai trò theo chất lượng, chi phí và quyền truy cập thực tế.

Ví dụ **User Settings**, điều chỉnh đường dẫn và model cho máy của bạn:

```json
{
  "aiTeam.profiles": [
    {
      "id": "codex-main", "label": "Codex · Main", "provider": "codex",
      "executable": "codex", "model": "", "effort": "medium",
      "env": {}, "secretEnv": []
    },
    {
      "id": "codex-second", "label": "Codex · Second", "provider": "codex",
      "executable": "codex", "model": "", "effort": "medium",
      "env": { "CODEX_HOME": "C:\\Users\\Admin\\.codex-second" }, "secretEnv": []
    },
    {
      "id": "claude-main", "label": "Claude · Audit", "provider": "claude",
      "executable": "claude", "model": "", "effort": "medium",
      "env": {}, "secretEnv": []
    },
    {
      "id": "gemini-main", "label": "Gemini · Worker", "provider": "gemini",
      "executable": "gemini", "model": "", "env": {}, "secretEnv": ["GEMINI_API_KEY"]
    }
  ],
  "aiTeam.maxChildTasks": 4,
  "aiTeam.autoSwitch": false,
  "aiTeam.timezone": "Asia/Bangkok"
}
```

Account ở đây là **CLI profile**, không phải account đã kiểm chứng danh tính. Profile thứ hai cần cấu hình và đăng nhập riêng theo cách CLI hỗ trợ. Codex có `CODEX_HOME`; Claude có `CLAUDE_CONFIG_DIR`. Không sao chép token đăng nhập hay thay đổi login mặc định của CLI. Gemini nhiều account nên dùng credentials/env do CLI hỗ trợ và cấu hình rõ từng profile.

Với API key: thêm tên biến vào `secretEnv`, chạy **AI Team: Store Profile Secret**. Giá trị lưu trong VS Code SecretStorage và chỉ đưa vào env tiến trình. `env` dành cho cấu hình không bí mật; không đặt token ở đó. Các secret do extension cung cấp được che trong response/log lưu lại. CLI vẫn có thể lưu session riêng theo hành vi của nó.

Đổi vai trò áp dụng cho task mới hoặc task còn trong hàng đợi được chọn. Task đang chạy và schedule đã lưu giữ team riêng. Muốn đổi team của schedule, pause rồi tạo schedule mới.

## Hạn mức và auto-switch

Sidebar và status bar cập nhật mỗi 15 giây. Bản MVP nhận quota từ:

- Snapshot nhập tay qua **Update Quota** (ghi nguồn `manual`).
- File JSON chuẩn hóa do integration bên ngoài cập nhật; đặt đường dẫn tuyệt đối ở `quotaFile` của profile.

```json
{
  "usedPercent": 72,
  "observedAt": "2026-10-16T08:00:00+07:00",
  "resetsAt": "2026-10-16T12:00:00+07:00",
  "source": "your quota integration"
}
```

Không có dữ liệu → `quota unknown`; quá 5 phút hoặc qua reset → `stale / reset`. Không suy đoán quota bằng token của task, không xem thiếu dữ liệu là 0%. File lỗi/mất làm quota của profile trở về unknown.

Khi bật `autoSwitch`, trước mỗi bước nếu profile có quota mới đạt ngưỡng (mặc định 95%), chọn profile khác **cùng provider, model và effort** với quota mới còn đủ. Không có account phù hợp → task dừng và báo lỗi. Profile quota unknown không được chọn làm account dự phòng. Nếu profile chính unknown/stale, CLI vẫn được thử và tự trả lỗi khi cần.

Bản này **chưa tự đọc quota subscription của từng nhà cung cấp**. Không tự retry sau lỗi rate-limit, timeout hoặc lỗi CLI vì task có thể đã sửa file một phần. Không chuyển model/provider âm thầm.

## Lịch chạy và reminder

**Schedule Task or Reminder** hỗ trợ một lần bằng ISO có UTC offset, hoặc cron lặp theo múi giờ cấu hình.

- `0 9 * * *`: mỗi ngày 09:00.
- `*/30 * * * *`: mỗi 30 phút.
- ISO ví dụ: `2026-10-17T09:00:00+07:00`.

Task lịch tự đưa vào cùng hàng đợi. Chỉ một task chạy tại một thời điểm trong workspace; việc con chạy tuần tự để tránh sửa cùng file. Mặc định tối đa 4 việc con/audit; có thể chỉnh 0–20. Audit vượt giới hạn hoặc JSON sai sẽ dừng, không cắt bớt âm thầm.

**VS Code phải mở và workspace phải được nạp.** Reminder bị lỡ được báo một lần khi mở lại; task tự động lỡ quá 60 giây được bỏ qua kèm thông báo. Cron bỏ qua backlog, không chạy bù hàng loạt. Run đang chạy/đang xếp hàng khi host tắt được đánh dấu `interrupted` khi mở lại; kiểm tra diff trước khi tạo task mới.

## Quyền, dữ liệu và báo cáo

Chỉ chạy trên trusted workspace. Profiles/credentials đặt ở User Settings. Codex dùng `read-only`/`workspace-write`; Claude dùng `plan`/`acceptEdits`; Gemini dùng `plan`/`auto_edit`. Extension không thêm cờ bỏ qua sandbox/permission. Các CLI vẫn chịu cấu hình, hook, tool permission và giới hạn riêng; đây không phải sandbox độc lập. Nếu CLI chờ quyền không xử lý được trong headless, task có thể lỗi hoặc timeout và cần cấu hình CLI trước khi chạy lại.

State, Markdown report và sanitized run log nằm trong workspace storage của VS Code, đường dẫn hiển thị đầu Output **AI Team**. Báo cáo có profile ID được chọn, vai trò, phản hồi, lỗi và issue drafts. Chưa tự đăng issue lên GitHub. Dữ liệu task được gửi cho các CLI/model đã gán trong pipeline. Chưa có nút xóa lịch sử; có thể mở đường dẫn storage và quản lý file sau khi đóng workspace.

Lock theo PID chặn runner trùng trong cùng workspace storage. Hai cửa sổ mở cùng folder theo cách khác nhau hoặc hai workspace khác nhau chứa cùng repo vẫn có thể trùng checkout; chưa hỗ trợ distributed lock/worktree isolation. Chỉ nên chạy một workspace cho mỗi checkout.

## Phát triển và kiểm thử

```powershell
npm ci
npm run check
npm test
npm run build
npm run package
```

F5 chạy Extension Development Host. Unit/integration tests dùng CLI giả, không tiêu hao quota thật. Xem `docs/ROADMAP.md` cho phần background service, các kênh Telegram/Zalo, live quota và nhiều agents song song.

## Tài liệu adapter

- [Official OpenAI documentation: CLI reference](https://developers.openai.com/codex/cli/reference) và [configuration](https://developers.openai.com/codex/config-reference).
- [Claude CLI reference](https://code.claude.com/docs/en/cli-reference) và [settings/account directory](https://code.claude.com/docs/en/settings).
- [Gemini headless JSON](https://geminicli.com/docs/cli/headless/) và [CLI options](https://geminicli.com/docs/cli/cli-reference/).
- [VS Code Tree View API](https://code.visualstudio.com/api/extension-guides/tree-view).
