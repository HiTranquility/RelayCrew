# Partial recovered source

Version: 0.3.0

Original project src files were recovered from the packaged esbuild sourcesContent. Original package metadata and shipped README/license are included where available. Tests, build scripts, lockfile, assets, Git history and other unbundled files are unavailable. This is not a full historical repository or a verified reproducible build.
