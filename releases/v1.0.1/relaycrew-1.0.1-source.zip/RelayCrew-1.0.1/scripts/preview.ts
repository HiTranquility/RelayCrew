import type {CliStatus} from '../src/adapters/cli/setup';
import {renderLiveSessionWindow} from '../src/ui/live-session-window';
import { mkdir, writeFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import {completionCandidates} from '../src/core/completion-notices';
import {renderAgentMapWindow} from '../src/ui/agent-map-window';
import { renderBoard } from '../src/ui/board';
import { flowEditor } from '../src/ui/flow-editor';
import { newJob } from '../src/core/engine';
import { emptyDailyPlan, startDailyPlan, syncDecisions } from '../src/core/daily-plan';
import type { Profile } from '../src/core/domain';

const profiles:Profile[]=[
  {id:'codex-dev',label:'Codex · Dev account',provider:'codex',executable:'codex',model:'configured-dev-model',effort:'medium'},
  {id:'claude-manager',label:'Claude · Primary manager',provider:'claude',executable:'claude',model:'configured-manager-model',effort:'high'},
  {id:'claude-support',label:'Claude · Supporting coordinator',provider:'claude',executable:'claude',model:'configured-review-model',effort:'medium'},
  {id:'gemini-worker',label:'Gemini · Excluded from daily plan',provider:'gemini',executable:'gemini',model:'configured-worker-model'},
  {id:'antigravity-worker',label:'Antigravity · Executor',provider:'antigravity',executable:'agy',modelPolicy:'cli'},
  {id:'local-ollama',label:'Local · Ollama review',provider:'compatible',transport:'http',hosting:'local',endpoint:'http://localhost:11434/v1',executable:'http',modelPolicy:'flagship'}
];
const roles={builder:'codex-dev',auditor:'claude-support',worker:'gemini-worker',lead:'claude-manager'};
const management={primaryProfileId:'claude-manager',coordinatorIds:['claude-support']};
const job=newJob('Add bounded API retries and report the result to the owner','/demo/relay-app',roles,undefined,{},management);
job.status='running';job.steps=[
  {role:'builder',title:'Implement',prompt:'Implement bounded retries with tests.',profileId:'codex-dev',model:'configured-dev-model',effort:'medium',status:'done',response:'Added bounded retries and timeout coverage. Tests passed.'},
  {role:'auditor',title:'Audit / create issues',prompt:'Audit the implementation and return evidence.',profileId:'claude-support',model:'configured-review-model',status:'running',startedAt:new Date(Date.now()-82_000).toISOString(),phase:'cli',timeoutAt:new Date(Date.now()+25*60_000).toISOString()},
  {role:'lead',coordinatorProfileId:'claude-support',title:'Coordinator report',prompt:'Report findings to the primary manager.',status:'pending'},
  {role:'lead',title:'Tech lead decision',prompt:'Review the evidence and decide.',status:'pending'}
];
job.sourceCwd='/demo/relay-app';job.cwd='/demo/worktrees/api-retries';job.isolationMode='worktree';
job.worktree={path:job.cwd,repository:job.sourceCwd,branch:'relaycrew/task-demo-api-retries',baseCommit:'demo-commit'};
job.acceptance=[{id:'demo-tests',text:'Retries are bounded and timeout tests pass.',checked:true},{id:'demo-review',text:'Audit evidence reviewed; no unresolved high-risk issues.',checked:false}];
job.timeline=[{at:new Date().toISOString(),from:'owner',to:'Dev · Codex',kind:'task',text:job.prompt},{at:new Date().toISOString(),from:'builder:codex-dev',to:'auditor:claude-support',kind:'response',text:'Retry implementation is ready. Please check timeout and rate-limit cases.'},{at:new Date().toISOString(),from:'auditor:claude-support',to:'orchestrator / observer',kind:'stream',text:'Reviewing the attempt budget and HTTP 429 coverage.'}];
const daily=emptyDailyPlan();startDailyPlan(daily,'/demo/relay-app','Asia/Bangkok',profiles.slice(0,3).map(p=>p.id),12,95);daily.accounts['gemini-worker']=false;daily.enabled=false;
const blocked=newJob('Choose a database migration strategy','/demo/relay-app',roles,undefined,{},management);blocked.status='waiting_owner';blocked.ownerQuestion='Should the migration preserve the existing API? Option A is compatible; option B changes the API. Recommendation: A.';blocked.steps[0].status='waiting_owner';blocked.steps[0].profileId='codex-dev';blocked.dailyItemId='demo-decision';
daily.items.push({id:'demo-decision',day:daily.day,profileId:'codex-dev',category:'task',prompt:'Choose a database migration strategy',jobId:blocked.id});syncDecisions(daily,[blocked]);
daily.items.push({id:'pending-review',day:daily.day,profileId:'claude-support',category:'task',prompt:'Review hotkey focus and keyboard accessibility; provide evidence.'});
const schedules=[{id:'demo-nightly',title:'Nightly regression review',kind:'task' as const,prompt:'Review regression risks and return evidence.',cwd:'/demo/relay-app',roles,nextAt:new Date(Date.now()+3600000).toISOString(),cron:'0 22 * * *',timezone:'Asia/Bangkok',durationMinutes:45,enabled:true},{id:'demo-reminder',title:'Product owner review',kind:'reminder' as const,prompt:'Review pending product decisions.',cwd:'/demo/relay-app',roles,nextAt:new Date(Date.now()+5400000).toISOString(),timezone:'Asia/Bangkok',durationMinutes:15,enabled:true}];
const cliStatuses:Record<string,CliStatus>={
 'codex-dev':{installed:true,authenticated:'yes',checkedAt:new Date().toISOString(),message:'CLI is installed and signed in.',identity:{email:'owner@example.com',plan:'plus',method:'chatgpt'},usage:{scope:'account',source:'DEMO · Codex native windows',observedAt:new Date().toISOString(),windows:[{id:'codex:primary',group:'codex',label:'5h',remainingPercent:60,resetsAt:new Date(Date.now()+3600000).toISOString()}]}},
 'antigravity-worker':{installed:true,authenticated:'unknown',checkedAt:new Date().toISOString(),message:'Native usage loaded. Signed-in email is not exposed by this CLI.',usage:{scope:'shared-cli',source:'DEMO · Antigravity /usage',observedAt:new Date().toISOString(),windows:[{id:'a',group:'Gemini Models',label:'Weekly',remainingPercent:80,resetsAt:new Date(Date.now()+86400000).toISOString()},{id:'b',group:'Claude and GPT models',label:'Weekly',remainingPercent:0,resetsAt:new Date(Date.now()+86400000).toISOString()},{id:'c',group:'Claude and GPT models',label:'Five Hour',disabled:true}]}}
};
const theme=':root{--vscode-font-size:13px;--vscode-editor-font-size:12px;--vscode-font-family:Segoe UI,Arial,sans-serif;--vscode-editor-font-family:Consolas,monospace;--vscode-foreground:#cccccc;--vscode-textLink-foreground:#4daafc;--vscode-testing-iconPassed:#73c991;--vscode-editorWarning-foreground:#cca700;--vscode-errorForeground:#f48771;--vscode-editor-background:#1f1f1f;--vscode-descriptionForeground:#9d9d9d;--vscode-panel-border:#3c3c3c;--vscode-focusBorder:#007fd4;--vscode-badge-background:#313131;--vscode-badge-foreground:#cccccc;--vscode-input-background:#313131;--vscode-input-foreground:#cccccc;--vscode-input-border:#3c3c3c;--vscode-button-background:#0078d4;--vscode-button-foreground:#ffffff;--vscode-button-hoverBackground:#026ec1;--vscode-button-secondaryBackground:#313131;--vscode-button-secondaryForeground:#cccccc;--vscode-button-secondaryHoverBackground:#3c3c3c;--vscode-editorGroupHeader-tabsBackground:#181818;--vscode-tab-activeBackground:#1f1f1f;--vscode-tab-activeForeground:#ffffff;--vscode-tab-inactiveForeground:#9d9d9d;--vscode-tab-activeBorderTop:#0078d4;--vscode-list-hoverBackground:#2b2d2e;--vscode-checkbox-background:#0078d4}';
async function main(){
  const dir=resolve('docs/previews');await mkdir(dir,{recursive:true});
  const fakeApi='({getState:()=>JSON.parse(sessionStorage.getItem("relaycrew-preview")||"{}"),setState:s=>sessionStorage.setItem("relaycrew-preview",JSON.stringify(s)),postMessage:m=>{(window.__messages||=[]).push(m);}})';
  const prepare=(html:string)=>html.replace('</style>',theme+'</style>').replace('acquireVsCodeApi()',fakeApi).replace('<body>','<body><div style="padding:6px 20px;font-size:11px;color:var(--vscode-descriptionForeground);border-bottom:1px solid var(--vscode-panel-border)">DEMO DATA · UI preview · No agents, accounts or deliveries run here.</div>').replace(/[ \t]+$/gm,'');
  for(const language of ['en','vi'] as const){
    const suffix=language==='en'?'':'.vi';await writeFile(join(dir,'live-session'+suffix+'.html'),prepare(renderLiveSessionWindow({...job,fileTracking:'active',fileChanges:[{path:'src/demo.ts',kind:'modified',at:new Date().toISOString(),stepIndex:0},{path:'test/demo.test.ts',kind:'added',at:new Date().toISOString(),stepIndex:0}]},profiles,language))); await writeFile(join(dir,'agent-map'+suffix+'.html'),prepare(renderAgentMapWindow([job,blocked],profiles,language,{selected:job.id,follow:true})));
    const policy=newJob('Choose how the manager team decides','/demo/relay-app',roles,undefined,{}, {...management,deciderIds:[management.primaryProfileId,...management.coordinatorIds],decisionPolicy:'ask'});policy.id='review-policy-demo';policy.status='waiting_owner';policy.decisionPolicyPending=true;
    const disputed=structuredClone(policy);disputed.id='review-vote-demo';disputed.prompt='Resolve recorded manager disagreement';disputed.decisionPolicyPending=false;disputed.reviewDecision={policy:'all',outcome:'blocked',votes:[{profileId:management.primaryProfileId,name:'Manager 1',decision:'approved',summary:'Owner scope verified.'},{profileId:management.coordinatorIds[0],name:'Manager 2',decision:'changes_requested',summary:'Concrete evidence still missing.'}]};
    await writeFile(join(dir,'board.review'+suffix+'.html'),prepare(renderBoard([policy,disputed],profiles,{}, {enabled:false,items:[],remaining:0,until:0},'',{queuePaused:false,autoSwitch:false,resumeAfterQuota:false,resumeProviderLimited:false,allowEdits:false,routingMode:'selected',timeoutMinutes:30,language,roles,management,flow:['builder','auditor','worker','lead'],projectRoots:[{name:'Relay App',path:'/demo/relay-app'},{name:'Design System',path:'/demo/design-system'}]})));
    await writeFile(join(dir,`flow${suffix}.html`),prepare(flowEditor(profiles,['builder','auditor','worker','lead'],roles,{},language,management)));
    await writeFile(join(dir,`board${suffix}.html`),prepare(renderBoard([job,blocked],profiles,Object.fromEntries(profiles.map((p,i)=>[p.id,{usedPercent:[42,68,35,18,15,8][i],observedAt:new Date().toISOString(),source:'demo only'}])),{enabled:false,items:[],remaining:0,until:0},'Telegram: two-way · demo\nZalo: webhook · demo',{queuePaused:false,autoSwitch:true,resumeAfterQuota:true,resumeProviderLimited:false,allowEdits:false,routingMode:'selected',timeoutMinutes:30,language,cliStatuses,completionNotices:completionCandidates([job,blocked]),languagePreference:language,roles,management,dailyPlan:daily,schedules,projectRoots:[{name:'Relay App',path:'/demo/relay-app'},{name:'Design System',path:'/demo/design-system'}],flow:['builder','auditor','worker','lead']})));
  }
  for(const language of ['en','vi'] as const)await writeFile(join(dir,language==='en'?'welcome.html':'welcome.vi.html'),prepare(renderBoard([],profiles,{}, {enabled:false,items:[],remaining:0,until:0},'No channels connected',{queuePaused:false,autoSwitch:false,resumeAfterQuota:false,resumeProviderLimited:false,allowEdits:false,routingMode:'selected',timeoutMinutes:30,language,roles,management,projectRoots:[{name:'Relay App',path:'/demo/relay-app'}]})));
  console.log(dir);
}
void main().catch(error=>{console.error(error);process.exitCode=1;});
